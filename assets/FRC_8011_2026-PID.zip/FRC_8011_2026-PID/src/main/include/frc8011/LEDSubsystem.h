#pragma once
#include <frc2/command/SubsystemBase.h>
#include <frc2/command/button/CommandXboxController.h>
#include <frc2/command/sysid/SysIdRoutine.h>
#include <frc/smartdashboard/SmartDashboard.h>

#include "Constants.h"
#include "frc8011/Wayimotor.h"
#include "subsystems/ExampleSubsystem.h"

#include <frc/smartdashboard/SendableChooser.h>
#include <frc/smartdashboard/SmartDashboard.h>

#include <ctre/phoenix6/CANBus.hpp>
#include <ctre/phoenix6/CANdle.hpp>

// 注意：不要在头文件里写 using namespace ctre::phoenix6; 会污染全局命名空间

class LEDSubsystem : public ExampleSubsystem {
 public:
  explicit LEDSubsystem(frc2::CommandXboxController& joystick_) : ExampleSubsystem(joystick_)
  {
    Initialization();
  }
  
  enum class AnimationType {
    None,
    Blue,
    Green,
    Red,
    Purple,
    Yellow,
    Fire,
    Rainbow,
    Strobe,       // 默认白光爆闪
    StrobeRed,    // 红色爆闪
    StrobeBlue,   // 蓝色爆闪
    StrobeGreen,  // 绿色爆闪
    StrobePurple, // 紫色爆闪
    StrobeYellow, // 黄色爆闪
    ColorFlow,
    Larson,       // 霹雳游侠来回扫描灯
  };

  LEDSubsystem();
  ~LEDSubsystem() = default;

  void Periodic() override;
  void SetLEDState(AnimationType _state) { m_animState = _state; }

 private:
  void Initialization();
  // --- Phoenix 6 CANdle 对象 ---
  ctre::phoenix6::CANBus m_canBus{"rio"};
  ctre::phoenix6::hardware::CANdle m_candle{26, m_canBus};

  // --- 状态追踪，防止狂发 CAN 指令 ---
  AnimationType m_animState{AnimationType::Red}; // 默认开机红色
  AnimationType m_lastAnimState{AnimationType::None};

  // --- 颜色常量定义 ---
  using RGBWColor = ctre::phoenix6::signals::RGBWColor;
  static constexpr RGBWColor kWhite = RGBWColor{255, 255, 255, 0} * 0.5; 
  static constexpr RGBWColor kRed = RGBWColor{255, 0, 0, 0}; 
  static constexpr RGBWColor kGreen = RGBWColor{0, 255, 0, 0}; 
  static constexpr RGBWColor kBlue = RGBWColor{0, 0, 255, 0}; 
  static constexpr RGBWColor kPurple = RGBWColor{128, 0, 128, 0}; 
  static constexpr RGBWColor kYellow = RGBWColor{255, 255, 0, 0}; 

  // --- 灯带分段配置 (Offset 和 NumLeds) ---
  // CANdle Phoenix6 API 要求传入: (起始位置, 灯珠数量)
  const int startIndex = 0;
  const int endIndex = 38;
};