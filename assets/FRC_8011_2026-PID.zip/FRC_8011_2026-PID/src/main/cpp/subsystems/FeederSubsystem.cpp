﻿// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

#include "subsystems/FeederSubsystem.h"
#include <cmath>
#include <frc/Timer.h>

using namespace subsystems;

void FeederSubsystem::Initialization()
{
  // ==========================================
  // 新版电机配置: Backward Feeder
  // ==========================================
  configs::TalonFXConfiguration backward_feeder_config{};
  backward_feeder_config.MotorOutput.Inverted = 1;
  configs::Slot0Configs &backward_feeder_slot0 = backward_feeder_config.Slot0;
  backward_feeder_slot0.kG = 0.;         
  backward_feeder_slot0.kS = 0.12;       
  backward_feeder_slot0.kV = 0.12;       
  backward_feeder_slot0.kA = 0;          
  backward_feeder_slot0.kP = 0.03;       
  backward_feeder_slot0.kI = 0;          
  backward_feeder_slot0.kD = 0.;         
  backward_feeder_slot0.GravityType = 0; 
  backward_feeder_config.CurrentLimits.SupplyCurrentLimit = 80_A;
  backward_feeder_config.CurrentLimits.SupplyCurrentLowerLimit = 80_A;
  backward_feeder_config.CurrentLimits.StatorCurrentLimit=120_A;
  backward_feeder_config.CurrentLimits.SupplyCurrentLimitEnable = true;

  ctre::phoenix::StatusCode backward_feeder_status = ctre::phoenix::StatusCode::StatusCodeNotInitialized;
  for (int i = 0; i < 5; ++i) {
    backward_feeder_status = backward_feeder_.Applyconfig(backward_feeder_config);
    if (backward_feeder_status.IsOK()) break;
  }
  backward_feeder_.setinvert(-1);
  backward_feeder_.setCurrent_Speed(0.2);

  // ==========================================
  // 新版电机配置: Upward Feeder
  // ==========================================
  configs::TalonFXConfiguration upward_feeder_config{};
  upward_feeder_config.MotorOutput.Inverted = 0;
  configs::Slot0Configs &upward_feeder_slot0 = upward_feeder_config.Slot0;
  upward_feeder_slot0.kG = 0.;         
  upward_feeder_slot0.kS = 11;          
  upward_feeder_slot0.kV = 0;        
  upward_feeder_slot0.kA = 0;          
  upward_feeder_slot0.kP = 9.5;        
  upward_feeder_slot0.kI = 0;        
  upward_feeder_slot0.kD = 0.;         
  upward_feeder_slot0.GravityType = 0; 

  upward_feeder_config.CurrentLimits.StatorCurrentLimit=120_A;
  upward_feeder_config.CurrentLimits.StatorCurrentLimitEnable = true;
  upward_feeder_config.CurrentLimits.SupplyCurrentLimit = 40_A;
  upward_feeder_config.CurrentLimits.SupplyCurrentLowerLimit=40_A;
  upward_feeder_config.CurrentLimits.SupplyCurrentLimitEnable = true;

  ctre::phoenix::StatusCode upward_feeder_status = ctre::phoenix::StatusCode::StatusCodeNotInitialized;
  for (int i = 0; i < 5; ++i) {
    upward_feeder_status = upward_feeder_.Applyconfig(upward_feeder_config);
    if (upward_feeder_status.IsOK()) break;
  }
  upward_feeder_.setinvert(-1);
  upward_feeder_.SetStatusSignalUpdateFrequency(50_Hz);
  //upward_feeder_.setPhysicalLimits(0, 360000, 200, 50); 
  //upward_feeder_.setgearRatio(1.0); 

  m_laserCan.set_ranging_mode(grpl::LaserCanRangingMode::Short);
  
  // 2. 设置时间预算为 33ms (约 30Hz 刷新率，抓球足够快)
  m_laserCan.set_timing_budget(grpl::LaserCanTimingBudget::TB33ms);
  
  // 3. (可选) 设置 ROI。比如缩小视野到中心 8x8，避开两侧机框
  m_laserCan.set_roi(grpl::LaserCanROI{ 8, 8, 4, 4 }); 

}
void FeederSubsystem::Periodic() {
  std::optional<grpl::LaserCanMeasurement> measurement = m_laserCan.get_measurement();

  //  极其重要：必须检查测量结果是否 "VALID" (有效)！
  if (measurement.has_value()&&measurement.value().status == grpl::LASERCAN_STATUS_VALID_MEASUREMENT) {
    curDisMe= measurement.value().distance_mm;
  }
  else{
    curDisMe=800;
  }
  havingBall=curDisMe<=520;
  frc::SmartDashboard::PutNumber("FeederLaserDis", curDisMe);
  frc::SmartDashboard::PutBoolean("FeederLaserCanBall", havingBall);
}

void FeederSubsystem::SetBackwardFeederCurrent(double current, double max_abs_duty_cycle) {
  backward_feeder_.setCurrent_Speed(max_abs_duty_cycle);
  backward_feeder_.setcurrent(current);
  backward_feeder_.Control();
}

void FeederSubsystem::SetUpwardFeederVelocity(double velocity) {
  upward_feeder_.setvelocitytorquecurrent(velocity);
  upward_feeder_.Control();
}

void FeederSubsystem::SetUpwardFeederCurrent(double current, double max_abs_duty_cycle) {
  upward_feeder_.setCurrent_Speed(max_abs_duty_cycle);
  upward_feeder_.setcurrent(current);
  upward_feeder_.Control();
}

void FeederSubsystem::setduty(double backward_duty, double upward_duty) {
  backward_feeder_.setNormalizedDutyCircle(backward_duty);
  upward_feeder_.setNormalizedDutyCircle(upward_duty);
  backward_feeder_.Control();
  upward_feeder_.Control();
}

void FeederSubsystem::SetBackwardFeederVelocity(double duty) {
  backward_feeder_.setNormalizedDutyCircle(duty); 
  backward_feeder_.Control();
}

void FeederSubsystem::SetBackwardFeederDuty(double duty) {
  backward_feeder_.setNormalizedDutyCircle(duty);
  backward_feeder_.Control();
}

void FeederSubsystem::SetUpwardDuty(double duty) {
  upward_feeder_.setNormalizedDutyCircle(duty);
  upward_feeder_.Control();
}

void FeederSubsystem::Stop() {
  backward_feeder_.setcoast();
  upward_feeder_.setcoast();
  
  backward_feeder_.Control();
  upward_feeder_.Control();

  upper_velocity_reached_once_ = false;
}

// ==========================================
// 状态获取接口 (获取新版电机的实时数据)
// ==========================================

double FeederSubsystem::GetUpwardFeederVelocity() {
  return upward_feeder_.GetVelocity();
}

double FeederSubsystem::GetBackwardFeederVelocity() {
  return backward_feeder_.GetVelocity();
}

double FeederSubsystem::GetUpwardFeederCurrent() {
  return upward_feeder_.GetCurrent();
}

// ==========================================
// Command 包装层
// ==========================================

frc2::CommandPtr FeederSubsystem::StopCommandPtr() {
  return this->RunOnce([this] { Stop(); });
}

frc2::CommandPtr FeederSubsystem::SetBackwardFeederCurrentCommandPtr(double current, double max_abs_duty_cycle) {
  return frc2::cmd::RunOnce([this, current, max_abs_duty_cycle] {
    SetBackwardFeederCurrent(current, max_abs_duty_cycle);
  });
}

frc2::CommandPtr FeederSubsystem::SetUpwardFeederCurrentCommandPtr(double current, double max_abs_duty_cycle) {
  return frc2::cmd::RunOnce([this, current, max_abs_duty_cycle] {
    SetUpwardFeederCurrent(current, max_abs_duty_cycle);
  });
}

frc2::CommandPtr FeederSubsystem::setdutyCommandPtr(double backward_duty, double upward_duty) {
  return frc2::cmd::RunOnce([this, backward_duty, upward_duty] {
    setduty(backward_duty, upward_duty);
  });
}

frc2::CommandPtr FeederSubsystem::SetBackwardFeederDutyCommandPtr(double duty) {
  return frc2::cmd::RunOnce([this, duty] { SetBackwardFeederDuty(duty); });
}

frc2::CommandPtr FeederSubsystem::SetBackwardFeederVelocityCommandPtr(double velocity) {
  return frc2::cmd::RunOnce([this, velocity] { SetBackwardFeederVelocity(velocity); });
}

frc2::CommandPtr FeederSubsystem::SetUpwardFeederVelocityCommandPtr(double velocity) {
  return frc2::cmd::RunOnce([this, velocity] { SetUpwardFeederVelocity(velocity); });
}

frc2::CommandPtr FeederSubsystem::HoldFeederVelocityCommandPtr(
    double backward_velocity, double upward_velocity) {
  return this->RunOnce([this, backward_velocity, upward_velocity] {
    SetBackwardFeederVelocity(backward_velocity);
    SetUpwardFeederVelocity(upward_velocity);
  });
}

frc2::CommandPtr FeederSubsystem::StartPreload(){
  return frc2::cmd::Sequence(
    frc2::cmd::Wait(units::second_t{8}),
    HoldFeederVelocityCommandPtr(0.2,3),
    frc2::cmd::WaitUntil([this]{return havingBall;}),
    frc2::cmd::Wait(units::second_t{0.7}),
    frc2::cmd::RunOnce([this]{wantToPreload=false;}),
    StopCommandPtr()
    
  );
}

void FeederSubsystem::SetPreload() {
  SetUpwardFeederCurrent(13.0, 0.25);
  SetBackwardFeederDuty(0.3);
}

frc2::CommandPtr FeederSubsystem::SetPreloadCommandPtr() {
  return this->RunOnce([this] { SetPreload(); });
}

void FeederSubsystem::SetUpperVelocityBANGBANG(double velocity) {
  double current_velocity = GetUpwardFeederVelocity();
  if (current_velocity < velocity) {
    SetUpwardDuty(1.0); // 没达到目标前满功率加速
  } else {
    SetUpwardDuty(0.0); // 达到目标后切断动力
  }
}

frc2::CommandPtr FeederSubsystem::SetUpperVelocityBANGBANGCommandPtr(double velocity) {
  return frc2::cmd::RunOnce([this, velocity] { SetUpperVelocityBANGBANG(velocity); });
}

void FeederSubsystem::SetUpperVelocitycombo(double velocity) {
  if (velocity <= 0.0) {
    Stop(); 
    return;
  }

  // 检测目标速度是否改变
  if (std::abs(velocity - combo_target_velocity_) > 1e-6) {
    combo_target_velocity_ = velocity;
    upper_velocity_reached_once_ = false;
  }

  const double current_velocity = GetUpwardFeederVelocity();

  if (!upper_velocity_reached_once_) {
    SetUpperVelocityBANGBANG(velocity); // 第一阶段：BangBang 狂暴起步
    if (current_velocity >= (velocity - kUpperVelocityReachTolerance)) {
      upper_velocity_reached_once_ = true;
    }
    return;
  }

  // 第二阶段：到达一次后，切入平滑的 FOC 闭环稳速
  SetUpwardFeederVelocity(velocity);
}

