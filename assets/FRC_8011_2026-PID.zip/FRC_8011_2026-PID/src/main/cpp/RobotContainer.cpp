// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

#include "RobotContainer.h"

#include <frc/smartdashboard/SmartDashboard.h>
#include <frc2/command/Commands.h>
#include <frc2/command/WaitCommand.h>
#include <pathplanner/lib/auto/AutoBuilder.h>

RobotContainer::RobotContainer()
    : 
      LEDsub(joystick),
      visionSub(&drivetrain, &LEDsub),
      shooterSub(joystick),
      feederSub(joystick),
      
      //weidaiSub(joystick),
      groundIntakeSub(joystick),
      complexcommand(&drivetrain, &visionSub, &shooterSub, &feederSub, //&weidaiSub,
                     &groundIntakeSub)
{
  shooterSub.SetFeederSubsystem(&feederSub);
  shooterSub.SetDrivetrainSubsystem(&drivetrain);
  drivetrain.setShooterSubSystem(&shooterSub);
  // 濞夈劌鍞絘uto娑撶挱vents閸涙垝鎶?
  // EventTrigger("Reset").OnTrue(ResetTranslationCommand());
  autoChooser = pathplanner::AutoBuilder::buildAutoChooser();
  frc::SmartDashboard::PutData("Auto Mode", &autoChooser);
  rot.EnableContinuousInput(-180,180);
  frc::RobotController::SetBrownoutVoltage(6.5_V);
  m_autoChooser.SetDefaultOption("Do Nothing (Safe)", AutoMode::kDoNothing);
  // 2. 添加你手写的所有高阶路线
  m_autoChooser.AddOption("OutAndDepot", AutoMode::OutDepot);
  m_autoChooser.AddOption("DoubleAutoBump", AutoMode::DoubleOutLeft);
  //m_autoChooser.AddOption("DoubleAutoRight", AutoMode::DoubleOutRight);
  m_autoChooser.AddOption("OutAndHP", AutoMode::OutAndHP);
  // m_autoChooser.AddOption("OutAndDepotRed", AutoMode::RedOutDepot);
  // m_autoChooser.AddOption("DoubleOutLeftRed",AutoMode::RedDoubleOutLeft);
  // m_autoChooser.AddOption("DoubleOutRightRed",AutoMode::RedDoubleOutRight);
  // m_autoChooser.AddOption("OutAndHPRed",AutoMode::RedOutAndHP);
  m_autoChooser.AddOption("Low",AutoMode::LowLeft);
  m_autoChooser.AddOption("Max",AutoMode::Max);
  m_autoChooser.AddOption("Double+Depot", AutoMode::DoubleDe);
  m_autoChooser.AddOption("LowNoBounce",AutoMode::LowLeftNoBounce);
  //m_autoChooser.AddOption("LowRightNoBounce", AutoMode::LowRightNoBounce);
  // 3. 推送到 Shuffleboard / SmartDashboard
  frc::SmartDashboard::PutData("Auto Mode", &m_autoChooser);
  ConfigureBindings();
}

void RobotContainer::ConfigureBindings() {
  // Input ownership note:
  // Periodic-owned inputs: LeftTrigger, RightTrigger.
  // Check docs/controller-input-map.md before adding new button bindings.
  // Note that X is defined as forward according to WPILib convention,
  // and Y is defined as to the left according to WPILib convention.
 #include <algorithm> // 为了使用 std::clamp
#include <frc/DriverStation.h>

drivetrain.SetDefaultCommand(
    drivetrain.ApplyRequest([this]() ->auto&& {
        
        // 1. 获取基础手柄输入
        double rawVx=0;
        double rawVy=0;
        units::radians_per_second_t rawRot=units::radians_per_second_t{0};
        if(frc::DriverStation::IsJoystickConnected(0)){
           rawVx = -joystick.GetLeftY(); // 对应底盘 X 轴 (前后)
           rawVy = -joystick.GetLeftX(); // 对应底盘 Y 轴 (左右)
           rawRot=-joystick.GetRightX() * MaxAngularRate * OperatorConstants::AngularSpeedRate;
        }
        else{
           rawVx = -joystick1.GetLeftY(); // 对应底盘 X 轴 (前后)
           rawVy = -joystick1.GetLeftX(); // 对应底盘 Y 轴 (左右)
           rawRot=-joystick1.GetRightX() * MaxAngularRate * OperatorConstants::AngularSpeedRate;
        }
        // 算出平移速度指令 (不论什么模式都要用到)
        auto vXCmd = rawVx * MaxSpeed * OperatorConstants::SpeedRate;
        auto vYCmd = rawVy * MaxSpeed * OperatorConstants::SpeedRate;
        if(ground_intake_prepared_){
          vXCmd*=1;
          vYCmd*=1;
        }
        return driveClosed
                .WithVelocityX(vXCmd)
                .WithVelocityY(vYCmd)
                .WithRotationalRate(rawRot);
        
    })
  );

  joystick.LeftBumper().WhileTrue(
    complexcommand.BackShootGo()
  );
  
  joystick.Start().OnTrue(
    frc2::cmd::Sequence(
    // complexcommand.StartStorageCommand(),
    // frc2::cmd::WaitUntil([this] { return weidaiSub.GetStorageNormPosition() > 0.7; }),
    complexcommand.GroundintakeresetCommand(),
    groundIntakeSub.SetPitchNormPositionCommandPtr(0.2)
    // frc2::cmd::WaitUntil([this] { return groundIntakeSub.GetPitchNormPosition() <= 0.08; })
    //     .WithTimeout(units::second_t{1.0}),
    // complexcommand.CloseStorageCommand(),
    // frc2::cmd::RunOnce([this]{ground_intake_prepared_=false;})
  ));

  joystick.RightTrigger()
  .OnTrue(complexcommand.GroundintakeresetCommand())
  .WhileTrue(
    frc2::cmd::Either(
        frc2::cmd::Parallel(
            // 1. 底盘负责瞄准
            RealTimeAimDrive(
                &drivetrain, &shooterSub,
                [this]() { return -joystick.GetLeftY(); }, 
                [this]() { return -joystick.GetLeftX(); },180  
            ).ToPtr(),
            
            // 2. 机制负责射球
            frc2::cmd::Sequence(
                complexcommand.GroundintakeresetCommand(),
                frc2::cmd::RunOnce([this] { ground_intake_prepared_ = false;}),
                //frc2::cmd::WaitUntil([this]{return drivetrain.SOMangleDiff<=20;}),
                shooterSub.EnableShooter(),
                frc2::cmd::RunOnce([this] {shooterEnabled = true; }),
                frc2::cmd::Parallel(
                complexcommand.ShootWithFeederCommand(),
                frc2::cmd::Sequence(
                frc2::cmd::WaitUntil([this]{return 
            std::abs(shooterSub.GetShootVelocity()-shooterSub.realShootVelocity)<0.7
            &&drivetrain.SOMangleDiff<=8;})
          .WithTimeout(units::second_t{1.5}),
                complexcommand.GroundintakeassistCommand()))
            )
        ),

        frc2::cmd::Parallel(
            // 1. 底盘和 Feeder 已经被 PassBallCommand 包办了
            PassBallCommand(
                &drivetrain, &shooterSub, &feederSub,
                [this]() { return -joystick.GetLeftY(); }, 
                [this]() { return -joystick.GetLeftX(); },180
            ).ToPtr(),
            // 2. 传球时附带的额外动作
            frc2::cmd::Sequence(
                complexcommand.GroundintakeresetCommand(),
                frc2::cmd::RunOnce([this] { ground_intake_prepared_ = false;}),
                frc2::cmd::WaitUntil([this]{return drivetrain.SOMangleDiff<=20;}),
                shooterSub.EnableShooter(),
                frc2::cmd::RunOnce([this] {shooterEnabled = true; }),
                frc2::cmd::WaitUntil([this]{return 
                  std::abs(shooterSub.GetShootVelocity()-shooterSub.realShootVelocity)<0.7
                  &&drivetrain.SOMangleDiff<=8;}).WithTimeout(units::second_t{1.5}),
                frc2::cmd::Sequence(
                    frc2::cmd::Sequence(
                      complexcommand.GroundintakeassistCommand(),
                      frc2::cmd::RunOnce([this] { ground_intake_prepared_ = false;}))
                    .OnlyIf([this]{
                      frc::Translation2d nowT=drivetrain.GetState().Pose.Translation();
                      return nowT.Y().value()<=3.5||nowT.Y().value()>=4.5;})
                )
            )
        ),
        [this] {
            auto alliance = frc::DriverStation::GetAlliance();
            bool isRed=alliance.has_value()&&alliance.value()==frc::DriverStation::Alliance::kRed;
            double x = drivetrain.GetState().Pose.X().value();
            return (!isRed&&x<=5.0) || (isRed&&x>=11.54);
        }
    )
).OnFalse(
    frc2::cmd::Sequence(
      complexcommand.GroundintakeresetCommand(),
        complexcommand.StopShootWithFeederCommand(),
        //complexcommand.GroundintakeresetCommand(),
        frc2::cmd::RunOnce([this] { shooterEnabled = false; })
    )
);

  // joystick.POVLeft().OnTrue(frc2::cmd::Either(
  //   shooterSub.EnableShooter(),
  //   complexcommand.StopShootWithFeederCommand(),
  //   [this]{return !shooterEnabled;}
  // ).AndThen(frc2::cmd::RunOnce(
  //             [this] { shooterEnabled = !shooterEnabled; }))
  // );

// 根据storage位置切换
// joystick.LeftBumper().OnTrue(
//     frc2::cmd::Either(
//         complexcommand.StartStorageCommand(),
//         complexcommand.CloseStorageCommand(),
//         [this] { return weidaiSub.GetStorageNormPosition() < 0.5; }
//     )
// );
 
  // joystick.B().WhileTrue(
  //     frc2::cmd::StartEnd(銆併€戙€愩€戙€愩€?
  //         [this]
  //         { shooterSub.SetShootVelocity(44
  //         ); }, // 瀵偓婵妞傞幍褑顢?
  //         [this]
  //         { shooterSub.Stop(); }, //
  //         缂佹挻娼敍鍫熸緱瀵偓閿涘妞傞幍褑顢?
  //         {&shooterSub}           // 閸忔娊鏁敍姘紣閺勫酣娓跺Ч?
  //         ));

  // //鎼存洜娲?SysId閵嗘垯鈧降鈧?
  // joystick.A().WhileTrue(drivetrain.SysIdQuasistatic(frc2::sysid::Direction::kForward));
  // joystick.B().WhileTrue(drivetrain.SysIdQuasistatic(frc2::sysid::Direction::kReverse));
  // joystick.X().WhileTrue(drivetrain.SysIdDynamic(frc2::sysid::Direction::kForward));
  // joystick.Y().WhileTrue(drivetrain.SysIdDynamic(frc2::sysid::Direction::kReverse));

  // // Shooter SysId
  // joystick.A().WhileTrue(shooterSub.SysIdQuasistatic(frc2::sysid::Direction::kForward));
  // joystick.B().WhileTrue(shooterSub.SysIdQuasistatic(frc2::sysid::Direction::kReverse));
  // joystick.X().WhileTrue(shooterSub.SysIdDynamic(frc2::sysid::Direction::kForward));
  // joystick.Y().WhileTrue(shooterSub.SysIdDynamic(frc2::sysid::Direction::kReverse));
  // // Feeder SysId
  // joystick.A().WhileTrue(feederSub.SysIdQuasistatic(frc2::sysid::Direction::kForward));
  // joystick.B().WhileTrue(feederSub.SysIdQuasistatic(frc2::sysid::Direction::kReverse));
  // joystick.X().WhileTrue(feederSub.SysIdDynamic(frc2::sysid::Direction::kForward));
  // joystick.Y().WhileTrue(feederSub.SysIdDynamic(frc2::sysid::Direction::kReverse));

  drivetrain.RegisterTelemetry(
       [this](auto const& state) { logger.Telemeterize(state); });

  joystick.RightBumper().WhileTrue(
    frc2::cmd::Sequence(
      //complexcommand.StopShootWithFeederCommand(),
      //complexcommand.GroundintakeresetCommand(),
      frc2::cmd::Either(
        complexcommand.PassBump(false),
        complexcommand.PassBump(true),
      [this]{
        auto alliance=frc::DriverStation::GetAlliance();
        double nowX=drivetrain.GetState().Pose.X().value();
        return (alliance.has_value()&&alliance.value()==frc::DriverStation::Alliance::kBlue&&nowX<=16.54/2)||(alliance.has_value()&&alliance.value()==frc::DriverStation::Alliance::kRed&&nowX>=16.54/2);
      })
  ));

  //增加使用默认速度选项，以防Limelight出问题
  joystick.POVUp().WhileTrue(//shooterSub.EnableDefaultShoot()
    frc2::cmd::Sequence(
      frc2::cmd::RunOnce([this]{visionSub.defaultShooting=true;}),
      frc2::cmd::Either(
        frc2::cmd::RunOnce([this]{
        drivetrain.ResetPose(defaultShootRedPose);}),
        frc2::cmd::RunOnce([this]{
        drivetrain.ResetPose(defaultShootBluePose);}),
        [this]{return frc::DriverStation::GetAlliance().has_value() && 
                             frc::DriverStation::GetAlliance().value() == frc::DriverStation::Alliance::kRed; } 
      ),
      frc2::cmd::Parallel(
            // 1. 底盘负责瞄准
            RealTimeAimDrive(
                &drivetrain, &shooterSub,
                [this]() { return -joystick.GetLeftY(); }, 
                [this]() { return -joystick.GetLeftX(); },180  
            ).ToPtr(),
            
            // 2. 机制负责射球
            frc2::cmd::Sequence(
                complexcommand.GroundintakeresetCommand(),
                frc2::cmd::RunOnce([this] { ground_intake_prepared_ = false;}),
                frc2::cmd::WaitUntil([this]{return drivetrain.SOMangleDiff<=20;}),
                shooterSub.EnableShooter(),
                frc2::cmd::RunOnce([this] {shooterEnabled = true; }),
                frc2::cmd::Parallel(
                complexcommand.ShootWithFeederCommand(),
                frc2::cmd::Sequence(
                frc2::cmd::WaitUntil([this]{return 
            std::abs(shooterSub.GetShootVelocity()-shooterSub.realShootVelocity)<0.7
            &&drivetrain.SOMangleDiff<=8;})
          .WithTimeout(units::second_t{1.5}),
                complexcommand.GroundintakeassistCommand()))
            )
        )

    )
  ).OnFalse(
    frc2::cmd::Sequence(
      frc2::cmd::RunOnce([this]{visionSub.defaultShooting=false;}),
      complexcommand.GroundintakeresetCommand(),
        complexcommand.StopShootWithFeederCommand(),
        //complexcommand.GroundintakeresetCommand(),
        frc2::cmd::RunOnce([this] { shooterEnabled = false; })
    )
);

  // joystick.POVDown().OnTrue(shooterSub.DisableDefaultShoot());

  joystick.POVRight().OnTrue(complexcommand.GroundintakeantiCommand()).OnFalse(complexcommand.GroundintakeresetCommand());

  joystick.A().WhileTrue(
    // frc2::cmd::Parallel(
    //   complexcommand.StartStorageCommand(),
    intakeNextToSide(          
            &drivetrain,  
            &shooterSub, 
            &groundIntakeSub,
            &joystick,
            true ).ToPtr()//)
          ).OnFalse(frc2::cmd::RunOnce( [this] { ground_intake_prepared_ = false;}));

  joystick.LeftTrigger().OnFalse(

        frc2::cmd::Sequence(
          complexcommand.GroundintakeresetCommand(),
          frc2::cmd::RunOnce( [this] { ground_intake_prepared_ = false;})))
          .WhileTrue(
            frc2::cmd::Sequence(
              frc2::cmd::RunOnce( [this] { ground_intake_prepared_ = true;}),
            // frc2::cmd::Parallel(
              complexcommand.GroundintakeprepareCommand()
              // complexcommand.StartStorageCommand().Repeatedly())
            ))
            .OnTrue(feederSub.StartPreload().OnlyIf([this]{return feederSub.wantToPreload;}));


   joystick.Y()
   .WhileTrue(
    frc2::cmd::Sequence(
    complexcommand.StopShootWithFeederCommand(),
    frc2::cmd::Parallel(
      frc2::cmd::Sequence(
        groundIntakeSub.SetPitchNormPositionCommandPtr(0.2).OnlyIf([this]{return drivetrain.GetState().Pose.X().value()<=5||drivetrain.GetState().Pose.X().value()>=11.54;}),
        frc2::cmd::WaitUntil([this]{
         double r = drivetrain.GetState().Pose.Rotation().Degrees().value();
         double x=drivetrain.GetState().Pose.X().value();
          return (x<8.27&&r<50&&r>-50)||(x>8.27&&(r>130||r<-130));}),
         groundIntakeSub.SetPitchNormPositionCommandPtr(GroundIntakeConstants::PitchNormPosition)
      ),
      frc2::cmd::Either(

        complexcommand.PassTrench(false),
        complexcommand.PassTrench(true),
      [this]{
        auto alliance=frc::DriverStation::GetAlliance();
        double nowX=drivetrain.GetState().Pose.X().value();
        return (alliance.has_value()&&alliance.value()==frc::DriverStation::Alliance::kBlue&&nowX<=16.54/2)||(alliance.has_value()&&alliance.value()==frc::DriverStation::Alliance::kRed&&nowX>=16.54/2);
      })
    )
    //)
  ));
  // joystick.LeftBumper().OnTrue(
  //     complexcommand.GroundintakeassistCommand()
  //         .AndThen(frc2::cmd::RunOnce(
  //             [this] { ground_intake_prepared_ = false; })));
  

  
  joystick.B().WhileTrue(
    // frc2::cmd::Parallel(
    //   complexcommand.StartStorageCommand(),
   frc2::cmd::Either(
        intakeNextToHub(
            &drivetrain,     // 你的 CommandSwerveDrivetrain 实例指针
            &shooterSub,   // 你的 ShooterSubsystem 实例指针
            &groundIntakeSub,
            &joystick,
            true    // 你的 GroundIntakeSubsystem 实例指针
        ).ToPtr(), 
        intakeNextToWall(&drivetrain, &shooterSub, &groundIntakeSub,&joystick, true).ToPtr(),
        [this]{
          double nowX=drivetrain.GetState().Pose.X().value();
          return nowX>5&&nowX<11.54;}
              )//)
            ).OnFalse(frc2::cmd::RunOnce( [this] { ground_intake_prepared_ = false;}));    // 转换为 WPILib 最新架构的 CommandPtr
  
  
  joystick.X().WhileTrue(
    // frc2::cmd::Parallel(
    //   complexcommand.StartStorageCommand(),
    frc2::cmd::Either(
        intakeNextToHub(
            &drivetrain,     // 你的 CommandSwerveDrivetrain 实例指针
            &shooterSub,   // 你的 ShooterSubsystem 实例指针
            &groundIntakeSub,
            &joystick,
            false    // 你的 GroundIntakeSubsystem 实例指针
        ).ToPtr(), 
        intakeNextToWall(&drivetrain, &shooterSub, &groundIntakeSub, &joystick,false).ToPtr(),
        [this]{
          double nowX=drivetrain.GetState().Pose.X().value();
          return nowX>5&&nowX<11.54;}
              )//)
            ).OnFalse(frc2::cmd::RunOnce( [this] { ground_intake_prepared_ = false;}));

    //joystick 1's buttons
    joystick1.LeftTrigger().WhileTrue(
      drivetrain.ApplyRequest([this]() ->auto&& {
        
        // 1. 获取基础手柄输入
        double rawVx=0;
        double rawVy=0;
        if(frc::DriverStation::IsJoystickConnected(0)){
           rawVx = -joystick.GetLeftY(); // 对应底盘 X 轴 (前后)
           rawVy = -joystick.GetLeftX(); // 对应底盘 Y 轴 (左右)
        }
        else{
           rawVx = -joystick1.GetLeftY(); // 对应底盘 X 轴 (前后)
           rawVy = -joystick1.GetLeftX(); // 对应底盘 Y 轴 (左右)
        }
        // 算出平移速度指令 (不论什么模式都要用到)
        auto vXCmd = rawVx * MaxSpeed * OperatorConstants::SpeedRate;
        auto vYCmd = rawVy * MaxSpeed * OperatorConstants::SpeedRate;
        if(ground_intake_prepared_){
          vXCmd*=1;
          vYCmd*=1;
        }
        double currentHeading=drivetrain.GetState().Pose.Rotation().Degrees().value();
        double tar=0;
        if((currentHeading>135)||(currentHeading<-135)){
          tar=180;
        }
        if(currentHeading>45&&currentHeading<=135){
          tar=90;
        }
        if(currentHeading<-45&&currentHeading>=-135){
          tar=-90;
        }
        return driveFace
                .WithVelocityX(vXCmd)
                .WithVelocityY(vYCmd)
                .WithTargetDirection(units::degree_t{tar});
        
      })//.Repeatedly()
    );

  joystick1.POVUp().OnTrue(
    frc2::cmd::Sequence(
    complexcommand.GroundintakeresetCommand(),
    groundIntakeSub.SetPitchNormPositionCommandPtr(0.07)
  ));


  joystick1.RightTrigger()
  .OnTrue(complexcommand.GroundintakeresetCommand())
  .WhileTrue(
    frc2::cmd::Either(
        frc2::cmd::Parallel(
            // 1. 底盘负责瞄准
            RealTimeAimDrive(
                &drivetrain, &shooterSub,
                [this]() { return -joystick1.GetLeftY(); }, 
                [this]() { return -joystick1.GetLeftX(); },180  
            ).ToPtr(),
            
            // 2. 机制负责射球
            frc2::cmd::Sequence(
                complexcommand.GroundintakeresetCommand(),
                frc2::cmd::RunOnce([this] { ground_intake_prepared_ = false;}),
                frc2::cmd::WaitUntil([this]{return drivetrain.SOMangleDiff<=20;}),
                shooterSub.EnableShooter(),
                frc2::cmd::RunOnce([this] {shooterEnabled = true; }),
                frc2::cmd::Parallel(
                complexcommand.ShootWithFeederCommand(),
                frc2::cmd::Sequence(
                frc2::cmd::WaitUntil([this]{return 
            std::abs(shooterSub.GetShootVelocity()-shooterSub.realShootVelocity)<0.7
            &&drivetrain.SOMangleDiff<=8;})
          .WithTimeout(units::second_t{1.5}),
                complexcommand.GroundintakeassistCommand()))
            )
        ),

        frc2::cmd::Parallel(
            // 1. 底盘和 Feeder 已经被 PassBallCommand 包办了
            PassBallCommand(
                &drivetrain, &shooterSub, &feederSub,
                [this]() { return -joystick1.GetLeftY(); }, 
                [this]() { return -joystick1.GetLeftX(); },180
            ).ToPtr(),
            // 2. 传球时附带的额外动作
            frc2::cmd::Sequence(
                complexcommand.GroundintakeresetCommand(),
                frc2::cmd::RunOnce([this] { ground_intake_prepared_ = false;}),
                frc2::cmd::WaitUntil([this]{return drivetrain.SOMangleDiff<=20;}),
                shooterSub.EnableShooter(),
                frc2::cmd::RunOnce([this] {shooterEnabled = true; }),
                frc2::cmd::WaitUntil([this]{return 
                  std::abs(shooterSub.GetShootVelocity()-shooterSub.realShootVelocity)<0.7
                  &&drivetrain.SOMangleDiff<=8;}).WithTimeout(units::second_t{1.5}),
                frc2::cmd::Sequence(
                    frc2::cmd::Sequence(
                      complexcommand.GroundintakeassistCommand(),
                      frc2::cmd::RunOnce([this] { ground_intake_prepared_ = false;}))
                    .OnlyIf([this]{
                      frc::Translation2d nowT=drivetrain.GetState().Pose.Translation();
                      return nowT.Y().value()<=3.5||nowT.Y().value()>=4.5;})
                )
            )
        ),
        [this] {
            auto alliance = frc::DriverStation::GetAlliance();
            bool isRed=alliance.has_value()&&alliance.value()==frc::DriverStation::Alliance::kRed;
            double x = drivetrain.GetState().Pose.X().value();
            return (!isRed&&x<=5.0) || (isRed&&x>=11.54);
        }
    )
).OnFalse(
    frc2::cmd::Sequence(
      complexcommand.GroundintakeresetCommand(),
        complexcommand.StopShootWithFeederCommand(),
        //complexcommand.GroundintakeresetCommand(),
        frc2::cmd::RunOnce([this] { shooterEnabled = false; })
    )
);

joystick1.X().WhileTrue(//shooterSub.EnableDefaultShoot()
    frc2::cmd::Sequence(
      frc2::cmd::Either(
        frc2::cmd::RunOnce([this]{
        drivetrain.ResetPose(defaultShootRedPose);}),
        frc2::cmd::RunOnce([this]{
        drivetrain.ResetPose(defaultShootBluePose);}),
        [this]{return frc::DriverStation::GetAlliance().has_value() && 
                             frc::DriverStation::GetAlliance().value() == frc::DriverStation::Alliance::kRed; } 
      ),
      frc2::cmd::Parallel(
            // 1. 底盘负责瞄准
            RealTimeAimDrive(
                &drivetrain, &shooterSub,
                [this]() { return -joystick1.GetLeftY(); }, 
                [this]() { return -joystick1.GetLeftX(); },180  
            ).ToPtr(),
            
            // 2. 机制负责射球
            frc2::cmd::Sequence(
                complexcommand.GroundintakeresetCommand(),
                frc2::cmd::RunOnce([this] { ground_intake_prepared_ = false;}),
                frc2::cmd::WaitUntil([this]{return drivetrain.SOMangleDiff<=20;}),
                shooterSub.EnableShooter(),
                frc2::cmd::RunOnce([this] {shooterEnabled = true; }),
                frc2::cmd::Parallel(
                complexcommand.ShootWithFeederCommand(),
                frc2::cmd::Sequence(
                frc2::cmd::WaitUntil([this]{return 
            std::abs(shooterSub.GetShootVelocity()-shooterSub.realShootVelocity)<0.7
            &&drivetrain.SOMangleDiff<=8;})
          .WithTimeout(units::second_t{1.5}),
                complexcommand.GroundintakeassistCommand()))
            )
        )

    )
  );

  joystick1.POVDown().OnTrue(
    frc2::cmd::RunOnce([this]{
      drivetrain.ResetRotation(frc::Rotation2d{units::degree_t{0}});
    })
  );

joystick1.B().WhileTrue(
    // frc2::cmd::Parallel(
    //   complexcommand.StartStorageCommand(),
    intakeNextToSide(          
            &drivetrain,  
            &shooterSub, 
            &groundIntakeSub,
            &joystick1,
            true ).ToPtr()//)
          ).OnFalse(frc2::cmd::RunOnce( [this] { ground_intake_prepared_ = false;}));

  joystick1.LeftBumper().OnFalse(

        frc2::cmd::Sequence(
          complexcommand.GroundintakeresetCommand(),
          frc2::cmd::RunOnce( [this] { ground_intake_prepared_ = false;})))
          .WhileTrue(
            frc2::cmd::Sequence(
              frc2::cmd::RunOnce( [this] { ground_intake_prepared_ = true;}),
            // frc2::cmd::Parallel(
              complexcommand.GroundintakeprepareCommand()
              // complexcommand.StartStorageCommand().Repeatedly())
            ));

    joystick1.RightBumper()
   .WhileTrue(
    frc2::cmd::Sequence(
      complexcommand.StopShootWithFeederCommand(),
      //complexcommand.CloseStorageCommand(),
      //complexcommand.GroundintakeresetCommand(),
      frc2::cmd::Either(
        complexcommand.PassTrench(false),
        complexcommand.PassTrench(true),
      [this]{
        auto alliance=frc::DriverStation::GetAlliance();
        double nowX=drivetrain.GetState().Pose.X().value();
        return (alliance.has_value()&&alliance.value()==frc::DriverStation::Alliance::kBlue&&nowX<=16.54/2)||(alliance.has_value()&&alliance.value()==frc::DriverStation::Alliance::kRed&&nowX>=16.54/2);
      })
    //)
  ));

  joystick1.Y().WhileTrue(
    // frc2::cmd::Parallel(
    //   complexcommand.StartStorageCommand(),
   frc2::cmd::Either(
        intakeNextToHub(
            &drivetrain,     // 你的 CommandSwerveDrivetrain 实例指针
            &shooterSub,   // 你的 ShooterSubsystem 实例指针
            &groundIntakeSub,
            &joystick1,
            true    // 你的 GroundIntakeSubsystem 实例指针
        ).ToPtr(), 
        intakeNextToWall(&drivetrain, &shooterSub, &groundIntakeSub,&joystick1, true).ToPtr(),
        [this]{
          double nowX=drivetrain.GetState().Pose.X().value();
          return nowX>5&&nowX<11.54;}
              )//)
            ).OnFalse(frc2::cmd::RunOnce( [this] { ground_intake_prepared_ = false;}));    // 转换为 WPILib 最新架构的 CommandPtr
  
  
  joystick1.A().WhileTrue(
    // frc2::cmd::Parallel(
    //   complexcommand.StartStorageCommand(),
    frc2::cmd::Either(
        intakeNextToHub(
            &drivetrain,     // 你的 CommandSwerveDrivetrain 实例指针
            &shooterSub,   // 你的 ShooterSubsystem 实例指针
            &groundIntakeSub,
            &joystick1,
            false    // 你的 GroundIntakeSubsystem 实例指针
        ).ToPtr(), 
        intakeNextToWall(&drivetrain, &shooterSub, &groundIntakeSub, &joystick1,false).ToPtr(),
        [this]{
          double nowX=drivetrain.GetState().Pose.X().value();
          return nowX>5&&nowX<11.54;}
              )//)
            ).OnFalse(frc2::cmd::RunOnce( [this] { ground_intake_prepared_ = false;}));
}

frc2::CommandPtr RobotContainer::GenerateAutoCommand(bool invertD) {
    AutoMode selectedMode = m_autoChooser.GetSelected();
    auto alliance=frc::DriverStation::GetAlliance();
    bool isRed=alliance.has_value()&&alliance.value()==frc::DriverStation::Alliance::kRed;

  switch (selectedMode) {
    case AutoMode::OutDepot:
      return autos::AutoSlowLeft(&drivetrain, &shooterSub, &feederSub, &groundIntakeSub, &complexcommand, isRed, isRed);
      
    case AutoMode::DoubleOutLeft:
      return autos::AutoDoubleLeft(&drivetrain, &shooterSub, &feederSub, &groundIntakeSub, &complexcommand, isRed, invertD);
      
    // case AutoMode::DoubleOutRight:
    //   return autos::AutoDoubleLeft(&drivetrain, &shooterSub, &feederSub, &groundIntakeSub, &complexcommand,isRed, !isRed);
      
    case AutoMode::OutAndHP:
      return autos::AutoHP(&drivetrain, &shooterSub, &feederSub, &groundIntakeSub, &complexcommand,isRed, isRed);
      
    case AutoMode::LowLeft:
      return autos::AutoLow(&drivetrain, &shooterSub, &feederSub, &groundIntakeSub, &complexcommand, isRed,invertD);
    
    // case AutoMode::LowRight:
    //   return autos::AutoLow(&drivetrain, &shooterSub, &feederSub, &groundIntakeSub, &complexcommand, isRed,!isRed);
    // case AutoMode::LowRightNoBounce:
    //   return autos::AutoLowOnlyOneSide(&drivetrain, &shooterSub, &feederSub, &groundIntakeSub, &complexcommand, isRed,!isRed);

    case AutoMode::LowLeftNoBounce:
      return autos::AutoLowOnlyOneSide(&drivetrain, &shooterSub, &feederSub, &groundIntakeSub, &complexcommand, isRed,invertD);
    case AutoMode::Max:
      return autos::AutoMax(&drivetrain, &shooterSub, &feederSub, &groundIntakeSub, &complexcommand, isRed,invertD);
    case AutoMode::DoubleDe:
      return autos::AutoLowAndDepot(&drivetrain, &shooterSub, &feederSub, &groundIntakeSub, &complexcommand, isRed,invertD);
    case AutoMode::kDoNothing:
    default:
      return frc2::cmd::None();
  }
}

void RobotContainer::refreshAutoMode(){
  // 1. 获取当前的 Enum 选择
    AutoMode currentSelection = m_autoChooser.GetSelected();
    if(drivetrain.GetState().Pose.Y().value()>=8.07/2){
      currentPlace=0;
    }
    else{
      currentPlace=1;
    }
    // 2. 如果发生了切换，或者缓存是空的
    if (currentPlace!=previousPlace||currentSelection != m_lastSelectedAuto || !m_preloadedAuto.has_value()) {
        frc::SmartDashboard::PutString("Auto Status", "WAITING!");
        m_lastSelectedAuto = currentSelection;
        // 3. 重新生成并装入盒子
        m_preloadedAuto = RobotContainer::GenerateAutoCommand(currentPlace);
        // 因为 enum 不能直接打印成字符串，我们可以简单地在面板上发个 Ready 信号
        frc::SmartDashboard::PutString("Auto Status", "READY!");
        previousPlace=currentPlace;
    }
}
frc2::CommandPtr RobotContainer::GetAutonomousCommand() {
  // 1. 检查盒子里有没有提前做好的指令
    if (m_preloadedAuto.has_value()) {
        // 2. 极其关键的 std::move！
        // 把控制权从 optional 转移给 WPILib 调度器
        frc2::CommandPtr autoCmd = std::move(m_preloadedAuto.value());
        // 3. 清空盒子。这样下次再回到 Disabled 状态时，它会重新生成
        m_preloadedAuto.reset(); 
        return autoCmd; // 瞬间返回，底层直接起飞！
    }
    // 万一出错了（比如刚开机还没过 Disabled 就强行进 Auto），给个保底的空指令
    return frc2::cmd::None();
}
