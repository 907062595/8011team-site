// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

#include "frc8011/LEDSubsystem.h" // 确保路径对应你的实际项目

// 🚨 架构师补丁：包含 Phoenix 6 CANdle 所有的控制请求
#include <ctre/phoenix6/controls/EmptyAnimation.hpp>
#include <ctre/phoenix6/controls/SolidColor.hpp>
#include <ctre/phoenix6/controls/RainbowAnimation.hpp>
#include <ctre/phoenix6/controls/FireAnimation.hpp>
#include <ctre/phoenix6/controls/StrobeAnimation.hpp>
#include <ctre/phoenix6/controls/LarsonAnimation.hpp>

using namespace ctre::phoenix6;


void LEDSubsystem::Initialization() {
  /* Configure CANdle */
  configs::CANdleConfiguration cfg{};
  
  // 架构师防坑：你已经改回 RGB 了，修复了颜色互换的问题！
  cfg.LED.StripType = signals::StripTypeValue::RGB;
  cfg.LED.BrightnessScalar = 1.0;
  
  /* disable status LED when being controlled */
  cfg.CANdleFeatures.StatusLedWhenActive = signals::StatusLedWhenActiveValue::Disabled;

  m_candle.GetConfigurator().Apply(cfg);

  /* 清理所有的预设动画 */
  for(int i = 0; i < 8; ++i){
      m_candle.SetControl(controls::EmptyAnimation{i});
  }

  // 开机默认强制刷一次
  m_lastAnimState = AnimationType::None;
  //SetLEDState(AnimationType::Red); 
}

void LEDSubsystem::Periodic() {
  // ==========================================
  // 核心优化：只有当状态真的改变时，才发送 CAN 帧
  // ==========================================
  if (m_animState == m_lastAnimState) {
    return; // 状态没变，直接跳过，节省大量 CAN 带宽！
  }
  
  // 记录新状态
  m_lastAnimState = m_animState;

  // 每次切换状态前，先清理之前可能在播放的复杂动画 (清空 Slot 0 即可)
  m_candle.SetControl(controls::EmptyAnimation{0});

  // 🚨 架构师终极修正：Phoenix 6 最新 API 强制要求传入 (起始下标, 结束下标)
  // 并且 EndIndex 是 inclusive（包含的）！

  switch (m_animState) {
    case AnimationType::None:
      // 全灭
      m_candle.SetControl(controls::SolidColor{startIndex, endIndex}.WithColor(RGBWColor{0,0,0,0}));
      break;

    case AnimationType::Red:
      m_candle.SetControl(controls::SolidColor{startIndex, endIndex}.WithColor(kRed));
      break;

    case AnimationType::Blue:
      m_candle.SetControl(controls::SolidColor{startIndex, endIndex}.WithColor(kBlue));
      break;

    case AnimationType::Green:
      m_candle.SetControl(controls::SolidColor{startIndex, endIndex}.WithColor(kGreen));
      break;

    case AnimationType::Purple:
      m_candle.SetControl(controls::SolidColor{startIndex, endIndex}.WithColor(kPurple));
      break;

    case AnimationType::Yellow:
      m_candle.SetControl(controls::SolidColor{startIndex, endIndex}.WithColor(kYellow));
      break;

    // ==========================================
    // 高级硬件动画 
    // ==========================================

    case AnimationType::Rainbow:
      // 彩虹流光
      m_candle.SetControl(controls::RainbowAnimation{startIndex, endIndex});
      break;

    case AnimationType::Fire:
      // 火焰效果
      m_candle.SetControl(controls::FireAnimation{startIndex, endIndex}.WithBrightness(1.0));
      break;

    // ==========================================
    // 各种颜色的爆闪 (Strobe) 特效
    // ==========================================

    case AnimationType::Strobe:
      // 默认爆闪 (白光)
      m_candle.SetControl(controls::StrobeAnimation{startIndex, endIndex}.WithColor(kWhite).WithFrameRate(units::frequency::hertz_t{10}));
      break; 
      
    case AnimationType::StrobeRed:
      // 红色爆闪 (极具警告意味)
      m_candle.SetControl(controls::StrobeAnimation{startIndex, endIndex}.WithColor(kRed).WithFrameRate(units::frequency::hertz_t{10}));
      break; 
      
    case AnimationType::StrobeBlue:
      // 蓝色爆闪
      m_candle.SetControl(controls::StrobeAnimation{startIndex, endIndex}.WithColor(kBlue).WithFrameRate(units::frequency::hertz_t{10}));
      break; 
      
    case AnimationType::StrobeGreen:
      // 绿色爆闪 (可以用来提示已瞄准或已获得抓取物)
      m_candle.SetControl(controls::StrobeAnimation{startIndex, endIndex}.WithColor(kGreen).WithFrameRate(units::frequency::hertz_t{10}));
      break; 
      
    case AnimationType::StrobePurple:
      // 紫色爆闪
      m_candle.SetControl(controls::StrobeAnimation{startIndex, endIndex}.WithColor(kPurple).WithFrameRate(units::frequency::hertz_t{10}));
      break; 
      
    case AnimationType::StrobeYellow:
      // 黄色爆闪
      m_candle.SetControl(controls::StrobeAnimation{startIndex, endIndex}.WithColor(kYellow).WithFrameRate(units::frequency::hertz_t{10}));
      break; 

    case AnimationType::Larson:
      // 霹雳游侠来回扫描灯
      m_candle.SetControl(controls::LarsonAnimation{startIndex, endIndex}.WithColor(kPurple));
      break;

    default:
      break;
  }
}